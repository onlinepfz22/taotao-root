create procedure getSubHealthList()
  BEGIN
	DECLARE _Done INT DEFAULT 0;
	DECLARE p_fac_code VARCHAR(50);/*设备条码*/
	DECLARE p_fac_price INT DEFAULT 0;/*设备购入价格*/
	DECLARE flag INT DEFAULT 0;
	DECLARE p_mal_fare INT DEFAULT 1;/*设备维修费用百分比*/
	DECLARE p_fac_sum_fare INT DEFAULT 0;/*设备维修总价格,默认每条设备的维修费用为0*/ 
	DECLARE p_fac_over_fare INT DEFAULT 0;/*当前设备维修总费用超过价格的百分比后的超过费用*/

	/*获取设置亚健康设备列表参数数据
				SELECT INTO语句再给变量赋值的情况下是存在大小写敏感状态，即SELECT的字段名称不能和
			INTO后用户自定义的变量名称相同，包括字段为大写，用户变量为将字段的大小完全转化为小写，这样将无法INTO相应字段的值

		SELECT MAL_FARE,MAL_YEAR_LIMIT INTO p_mal_fare,p_mal_year_limit FROM po_subhealth;*/

	/*根据设备维修费用百分比名称开始逐一对维修记录表中的记录进行维修费用超过p_mal_fare百分比进行判断，形成亚健康设备列表*/
	/*
		1、对维修记录表中的所有记录信息根据设备条码进行全部分组
		2、查询当前每个设备条码所代表的设备的起初购置价格，用于维修费用比对，也即维修费用已超过设备购买价格的p_mal_fare百分比
		3、将维修记录表中根据设备条码分组后的每条设备的设备条码进行维修总分用价格相加
		4、计算：每条设备的维修总费用 * p_mal_fare > 当前设备的起初购买价格，则插入记录到亚健康设备列表中，插入前先删除
	*/
	DECLARE rs_po_malFunction CURSOR FOR SELECT po_facility.FAC_CODE,po_facility.FAC_PRICE FROM po_facility;
	DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _Done = 1;

	SELECT MAL_FARE FROM po_subhealth INTO p_mal_fare;/*获取并设置维修费用超过百分比*/

	OPEN rs_po_malFunction; 	
		FETCH rs_po_malFunction INTO p_fac_code,p_fac_price;
			
		REPEAT
			IF NOT _Done THEN 
				IF p_fac_code = '' THEN 
					SET flag = 0;
				ELSE IF p_fac_code IS NULL THEN 
					SET flag = 0;
				ELSE 
					/*开始计算每个设备的维修总费用*/
					SELECT SUM(MAL_CASHIER) FROM po_malfunction WHERE MAL_CODE = p_fac_code INTO p_fac_sum_fare;
			
					IF p_fac_sum_fare >= 0 THEN 
											/*计算是否符合亚健康设备的条件,(当前维修总费用 - 当前设备价格*超过百分比)*/
						SET p_fac_over_fare = p_fac_sum_fare - (p_fac_price * p_mal_fare / 100);

						IF p_fac_over_fare >= 0 THEN 
							/*符合亚健康条件，则对设备档案表中的当前设备条码所代表的设备进行维修费用超过标记，形成亚健康设备*/
							UPDATE po_facility SET FAC_SUB_HEALTH = 'SUB_HEALTHY' WHERE FAC_CODE =  p_fac_code;
							SET flag =  p_fac_over_fare;
						ELSE
							UPDATE po_facility SET FAC_SUB_HEALTH = 'SUB_NOT_HEALTHY' WHERE FAC_CODE = p_fac_code;
							SET flag =  p_fac_over_fare;
						END IF;
					END IF;
				END IF;
				END IF;
			END IF;
		/*逐一取出po_facility中每一个设备条码值，设备条码不会重复*/
		FETCH rs_po_malFunction INTO p_fac_code,p_fac_price;
		UNTIL _Done=1
		END REPEAT;
	CLOSE rs_po_malFunction;
	SELECT flag;
END;

