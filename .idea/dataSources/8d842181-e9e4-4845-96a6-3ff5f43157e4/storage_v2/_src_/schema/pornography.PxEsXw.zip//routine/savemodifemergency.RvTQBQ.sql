create procedure saveModifEmergency(IN iden          int, IN emerTypeId int, IN emerDes longtext,
                                    IN emerDesFormat longtext, IN emerDesHtml longtext, IN timeF varchar(20),
                                    IN status        int(1), OUT result varchar(10))
  BEGIN
		#Routine body goes here...
	DECLARE rowCount INT DEFAULT 0;

	/*插入设备类型操作规程*/
	update po_emergency 

		set emerTypeId = emerTypeId ,

			emerDes = emerDes,

			emerDesFormat = emerDesFormat,

			emerDesHtml = emerDesHtml,

			time = timeF,

			status = status  
	
	where id = iden;

	SET rowCount=ROW_COUNT();
					
	IF rowCount=0 THEN
		SET result="false";
	ELSE
		SET result="true";
	END IF;

END;

