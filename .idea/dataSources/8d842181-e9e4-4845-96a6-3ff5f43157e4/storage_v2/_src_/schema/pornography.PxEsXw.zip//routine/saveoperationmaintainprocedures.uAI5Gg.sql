create procedure saveOperationMaintainProcedures(IN  facTypeId        int, IN proName varchar(80),
                                                 IN  proContextHtml   longtext, IN proFormatContext longtext,
                                                 IN  proContext       longtext, IN proImg longtext,
                                                 IN  proDate          varchar(30), IN proFlag varchar(30),
                                                 OUT result           varchar(10))
  BEGIN
	DECLARE rowCount INT DEFAULT 0;

	/*插入设备类型操作规程*/
	INSERT INTO po_procedures(FAC_TYPE_ID,PRO_NAME,PRO_CONTEXT_HTML,PRO_FORMAT_CONTEXT,PRO_CONTEXT,PRO_IMG,PRO_DATE,PRO_FLAG) 
	VALUES(facTypeId,proName,proContextHtml,proFormatContext,proContext,proImg,proDate,proFlag);

	SET rowCount=ROW_COUNT();
					
	IF rowCount=0 THEN
		SET result="false";
	ELSE
		SET result="true";
	END IF;
END;

