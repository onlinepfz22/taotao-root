create procedure saveEmergency(IN emerTypeId  int, IN emerDes longtext, IN emerDesFormat longtext,
                               IN emerDesHtml longtext, IN time varchar(20), IN status int(1), OUT result varchar(10))
  BEGIN
	#Routine body goes here...
	DECLARE rowCount INT DEFAULT 0;

	/*插入设备类型操作规程*/
	INSERT INTO po_emergency(emerTypeId,emerDes,emerDesFormat,emerDesHtml,time,status) 
	VALUES(emerTypeId,emerDes,emerDesFormat,emerDesHtml,time,status);

	SET rowCount=ROW_COUNT();
					
	IF rowCount=0 THEN
		SET result="false";
	ELSE
		SET result="true";
	END IF;
END;

