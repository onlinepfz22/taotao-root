create procedure judge_clothing_dispatch(OUT returnResult longtext)
  BEGIN

	DECLARE _Done INT DEFAULT 0;

	DECLARE usePerson_c VARCHAR(20);
	DECLARE deptName_c VARCHAR(20);
	DECLARE post_c VARCHAR(20);
	DECLARE para1_c VARCHAR(20);
	DECLARE para2_c VARCHAR(20);
	DECLARE para3_c VARCHAR(20);
	DECLARE para4_c VARCHAR(20);
	DECLARE para5_c VARCHAR(20);
	DECLARE para6_c VARCHAR(20);
	DECLARE para7_c VARCHAR(20);
	DECLARE para8_c VARCHAR(20);
	DECLARE para9_c VARCHAR(20);
	DECLARE para10_c VARCHAR(20);
	DECLARE para11_c VARCHAR(20);
	DECLARE para12_c VARCHAR(20);
	DECLARE para13_c VARCHAR(20);

	/*声明游标循环遍历office_logistics_clothing表中*/
	DECLARE rs_office_logistics_clothing CURSOR FOR SELECT usePerson,deptName,post,para1,para2,para3,para4,para5,para6,para7,para8,para9,para10,para11,para12,para13 FROM office_logistics_clothing;
	
	DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET _Done = 1;
	
	/*打开游标*/
	OPEN rs_office_logistics_clothing; 

	FETCH rs_office_logistics_clothing INTO usePerson_c,deptName_c,post_c,para1_c,para2_c,para3_c,para4_c,para5_c,para6_c,para7_c,para8_c,para9_c,para10_c,para11_c,para12_c,para13_c;
		REPEAT
			 IF NOT _Done THEN
				/*开始判断每个人的每个服装类型是否需要进行发放*/
				SET returnResult = "";
			 END IF;

			 FETCH rs_office_logistics_clothing INTO usePerson_c,deptName_c,post_c,para1_c,para2_c,para3_c,para4_c,para5_c,para6_c,para7_c,para8_c,para9_c,para10_c,para11_c,para12_c,para13_c;
			 UNTIL _Done=1
		END REPEAT;  
END;

