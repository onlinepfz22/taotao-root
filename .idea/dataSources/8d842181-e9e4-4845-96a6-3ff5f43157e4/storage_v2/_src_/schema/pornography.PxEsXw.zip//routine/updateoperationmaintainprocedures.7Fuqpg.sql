create procedure updateOperationMaintainProcedures(IN  id               int, IN proName varchar(80),
                                                   IN  proContextHtml   longtext, IN proFormatContext longtext,
                                                   IN  proContext       longtext, IN proImg longtext,
                                                   IN  proDate          varchar(30), IN proFlag varchar(30),
                                                   OUT result           varchar(10))
  BEGIN
	#Routine body goes here...
	DECLARE rowCount INT DEFAULT 0;

	IF proImg = '暂无图片' THEN 
		UPDATE po_procedures pp 
		SET pp.PRO_NAME = proName,
			pp.PRO_CONTEXT_HTML = proContextHtml,
			pp.PRO_FORMAT_CONTEXT = proFormatContext,
			pp.PRO_CONTEXT = proContext,
			pp.PRO_DATE = proDate,
			pp.PRO_FLAG = 'noFlag' 
		WHERE pp.ID = id;
	ELSE 
		UPDATE po_procedures pp 
		SET pp.PRO_NAME = proName,
			pp.PRO_CONTEXT_HTML = proContextHtml,
			pp.PRO_FORMAT_CONTEXT = proFormatContext,
			pp.PRO_CONTEXT = proContext,
			pp.PRO_IMG = proImg,
			pp.PRO_DATE = proDate,
			pp.PRO_FLAG = 'noFlag' 
		WHERE pp.ID  = id;
	END IF;
	
	SET rowCount=ROW_COUNT();
					
	IF rowCount = 0 THEN
		SET result = 'false';
	ELSE
		SET result = 'true';
	END IF;
END;

